package dev.InnocentUdo.Static_web_application_with_SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaticWebApplicationWithSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
