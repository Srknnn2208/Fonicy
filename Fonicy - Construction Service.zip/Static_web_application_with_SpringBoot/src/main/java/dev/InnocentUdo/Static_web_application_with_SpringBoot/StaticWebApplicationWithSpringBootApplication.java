package dev.InnocentUdo.Static_web_application_with_SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StaticWebApplicationWithSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(StaticWebApplicationWithSpringBootApplication.class, args);
	}

}
