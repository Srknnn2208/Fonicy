# FRONTEND VIEW

<img src="https://github.com/Innocentsax/FULL_STACK_PROJECTS/blob/main/Static_web_application_with_SpringBoot/cons1.png">

## Frontend tools i use for this project

+ ___HTML___
+ ___CSS___
+ ___Tailwind CSS___
+ ___JavaScript___



# BACKEND VIEW

<img src="https://github.com/Innocentsax/FULL_STACK_PROJECTS/blob/main/Static_web_application_with_SpringBoot/con2.png">

## Backend tools i use for this project

+ ___Java___
+ ___SpringBoot___


## Author
___[INNOCENT UDO](https://github.com/Innocentsax)___
